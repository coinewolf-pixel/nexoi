# NEXORUM — Public Website (No Admin)

## What's inside
- Public website: Home, Features, Pricing, Blog, Contact, About
- API calls to backend (Supabase + Cloudflare Workers)
- NO admin panel — manage content via API directly

## Quick Start

```bash
npm install
npm run build
```

After build, upload the `dist/` folder to Cloudflare Pages (drag-and-drop).

## API Admin (separate)
The API with admin endpoints is in `api/` folder. Deploy separately to Cloudflare Workers:

```bash
cd api
npm install
npx wrangler deploy
```

## Supabase Setup
1. Create project at supabase.com
2. Run migrations from `supabase/migrations/`
3. Enable Storage bucket `media`
