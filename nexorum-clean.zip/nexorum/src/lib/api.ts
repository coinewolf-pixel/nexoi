import axios from 'axios'

const API_URL = import.meta.env.VITE_API_URL || ''
const BUSINESS_SLUG = 'nexorum'

const api = axios.create({ baseURL: API_URL, headers: { 'Content-Type': 'application/json' } })

export const publicApi = {
  getBusiness: (slug: string) => api.get(`/api/businesses/${slug}`),
  getPages: (slug: string) => api.get(`/api/businesses/${slug}/pages`),
  getBlogPosts: (slug: string) => api.get(`/api/businesses/${slug}/blog`),
  getBlogPost: (slug: string, postSlug: string) => api.get(`/api/businesses/${slug}/blog/${postSlug}`),
  getTestimonials: (slug: string) => api.get(`/api/businesses/${slug}/testimonials`),
  getPartners: (slug: string) => api.get(`/api/businesses/${slug}/partners`),
  getFAQs: (slug: string) => api.get(`/api/businesses/${slug}/faqs`),
  getPricing: (slug: string) => api.get(`/api/businesses/${slug}/pricing`),
  getRoadmap: (slug: string) => api.get(`/api/businesses/${slug}/roadmap`),
  submitContact: (slug: string, data: any) => api.post(`/api/businesses/${slug}/contact`, data),
}

export default api
